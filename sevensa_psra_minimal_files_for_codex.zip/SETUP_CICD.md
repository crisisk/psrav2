# 🚀 Sevensa PSRA-LTSD — Minimal CI/CD

## Upload deze bestanden
- `.github/workflows/deploy.yml`
- `k8s/psra.yaml`  (gebruik deze als GHCR image **public** is)
- `k8s/psra-private.yaml`  (gebruik deze i.p.v. psra.yaml als GHCR image **privé** is)
- `traefik/psra.yml`  (referentie; op de VPS plaatsen onder Traefik dynamic)

## Wat Codex/ManusAI moet doen
1. **Validatie repo-structuur**
   - Bestaan de paden exact zo: `.github/workflows/deploy.yml`, `k8s/psra.yaml`?
2. **Repository secret controleren/zetten**
   - `KUBECONFIG_B64` moet aanwezig zijn (base64 van `/etc/rancher/k3s/k3s.yaml`).
3. **Kubernetes (eenmalig)**
   - `kubectl get ns sevensa || kubectl create ns sevensa`
   - `kubectl apply -f k8s/psra.yaml` (of `k8s/psra-private.yaml` wanneer GHCR privé is)
4. **Traefik (host)**
   - Plaats `traefik/psra.yml` op de VPS onder de dynamic map van Traefik (bijv. `/etc/traefik/dynamic/psra.yml`).
   - `sudo systemctl reload traefik`
5. **Trigger build/deploy**
   - Push naar `main` → Action bouwt `:latest` → zet live op `sevensa/psra-new`.
6. **Verifiëren**
   - `kubectl -n sevensa rollout status deploy/psra-new`
   - `curl -I https://psra.sevensa.nl`

## Rollback
```bash
kubectl -n sevensa rollout undo deploy/psra-new
```

## Notities
- Health path is `/api/health`. Pas aan naar `/healthz` indien nodig (in `k8s/psra*.yaml`).
- Voor privé GHCR: maak imagePullSecret `ghcr-pull-secret` aan in `sevensa`.
